const router=require('express').Router()
const fetch=require('node-fetch')


router.get('/',(req,res)=>{
    fetch('https://raw.githubusercontent.com/christkv/ecommerce/master/preload_data/products.json')
.then(respo=>respo.text())
.then(data=>
    {
        res.json(data)
    }
    )
})

module.exports=router